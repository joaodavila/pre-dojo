package com.jogo.main;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import javax.swing.plaf.basic.BasicInternalFrameTitlePane.MaximizeAction;

import com.jogo.modelo.Jogador;

public class GeradorCSV {
	
	public static void geraArquivoCsv(List<Jogador> jogadores,String sequencia,String nome,String saida){
	    try
	    {
	        FileWriter writer = new FileWriter(saida);

	        //cabe�alho
	        writer.append("Nome");
	        writer.append(';');
	        writer.append("Assassinatos");
	        writer.append(';');
	        writer.append("Mortes");
	        writer.append(";");
	        writer.append("ArmaPreferida");
	        writer.append(";");
	        writer.append("Awards");
	        writer.append('\n');
	        //conte�do
	        int primeiraLinha = 0;
	        for(Jogador j : jogadores){
	        	writer.append(j.getNome());
	        	writer.append(';');
	        	writer.append(String.valueOf(j.getQuantidadeAssassinatos()));
	        	writer.append(';');
	        	writer.append(String.valueOf(j.getQuantidadeMortes()));
	        	writer.append(';');
	        	if(primeiraLinha < 1){
	        		writer.append(j.getArmas().get(0).getNome());
	        		primeiraLinha++;
	        	}else{
	        		writer.append("  ");
	        	}
	        	writer.append(';');
	        	writer.append(String.valueOf(j.getAwards()));
	        	writer.append('\n');
	        }
	        
	        //String.valueOf(numero)
	        //linha final
	        String s ="A maior sequencia de assassinatos foi: "+sequencia+" feita por "+nome;
	        writer.append(s);
	        
	        //maior sequencia sem morrer
	        //

	        writer.flush();
	        writer.close();
	    }
	    catch(IOException e)
	    {
	         e.printStackTrace();
	    } 
	    }

}
