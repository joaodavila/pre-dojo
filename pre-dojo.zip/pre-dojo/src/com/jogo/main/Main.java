package com.jogo.main;

import java.util.List;

import com.jogo.dao.PartidaDAO;
import com.jogo.modelo.Jogador;

public class Main {
	
	public static void main(String[] args) {
		//String txt1 = "\\docs\\partida1.txt";
		String txt2 = "\\docs\\partida2.txt";
		PartidaDAO partida = new PartidaDAO();
		List<Jogador> jogadores = partida.obtemRanking(txt2);
		String maiorSequencia = String.valueOf(partida.getMaiorSequencia());
		String jogadorComMaiorSequencia = String.valueOf(partida.getNomeMaiorSequencia());
		GeradorCSV.geraArquivoCsv(jogadores, maiorSequencia, jogadorComMaiorSequencia, "docs\\ranking.csv");
	}
}
