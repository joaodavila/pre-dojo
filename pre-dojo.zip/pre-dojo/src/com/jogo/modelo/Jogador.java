package com.jogo.modelo;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;

import com.jogo.util.Utilitaria;

public class Jogador implements Comparable<Jogador>{
	
	private String nome;
	private int quantidadeMortes;
	private int quantidadeAssassinatos;
	private int sequencia;
	private int awards = 0;
	
	private Calendar ts;
	
	private List<Arma> armas;	

	public Calendar getTs() {
		return ts;
	}

	public void setTs(Calendar ts) {
		this.ts = ts;
	}

	public Jogador(String nome) {
		this.nome = nome;		
	}
	
	public List<Arma> getArmas() {
		if (this.armas == null) {
			this.armas = new ArrayList<>();
		}
		return armas;
	}

	public int getSequencia() {
		return sequencia;
	}

	public String getNome() {
		return this.nome;
	}

	public void setNome(String nome) {
		this.nome = nome;		
	}

	public int getQuantidadeMortes() {		
		return this.quantidadeMortes;
	}
	
	public void addQuantidadeMortes() {
		this.quantidadeMortes++;		
	}

	public int getQuantidadeAssassinatos() {
		return this.quantidadeAssassinatos;
	}

	public void aumentaAssassinatos(Calendar dataHoraAtual) {
		this.quantidadeAssassinatos++;
		if(sequencia == 0){
			this.ts = dataHoraAtual;
		}
		this.sequencia++;
		if(sequencia == 5){
			Utilitaria util = new Utilitaria();
			long intervalo = util.calculaIntervaloEmSegundos(this.ts,dataHoraAtual);
			if(intervalo < 60){
				ganhaAward();
			}
		}
	}

	public int getAwards() {
		return this.awards;
	}

	public void aumentaMortes() {
		this.quantidadeMortes++;
		this.sequencia = 0;
	}
	
	public void ganhaAward(){
		this.awards++;
	}
	
	public void addArma(Arma arma) {

		if (!getArmas().isEmpty() && getArmas().contains(arma)) {
			Iterator<?> iterator = armas.iterator();
			while (iterator.hasNext()) {
				Arma a = (Arma) iterator.next();
				if(a.equals(arma)){
					a.aumentaQuantidade();
				}				
			}
		} else {
			arma.aumentaQuantidade();
			armas.add(arma);
		}		
	}

	@Override
	public int compareTo(Jogador outro) {
		if (this.getQuantidadeAssassinatos() > outro.getQuantidadeAssassinatos()) {
			return -1;
		}
		if (this.getQuantidadeAssassinatos() < outro.getQuantidadeAssassinatos()) {
			return 1;
		}
		if (this.getQuantidadeMortes() < outro.getQuantidadeMortes()) {
			return -1;
		}
		if (this.getQuantidadeMortes() > outro.getQuantidadeMortes()) {
			return 1;
		}
		return 0;
	}

	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof Jogador)) {
			return false;
		}
		Jogador jogador = (Jogador) obj;

		if (jogador.getNome() != null && this.nome != null) {
			return jogador.getNome().equals(this.nome);
		}
		return false;
	}

	@Override
	public int hashCode() {
		return this.nome != null ? this.nome.hashCode():0;
	}

	@Override
	public String toString() {
		
		return this.nome+" "+this.quantidadeAssassinatos+" "+this.quantidadeMortes;
	}


	
}
