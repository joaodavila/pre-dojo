package com.jogo.modelo;

public enum TipoProcesso {
	ASSASSINO, MORTO

}
