package com.jogo.modelo;

public class Arma implements Comparable<Arma> {
	
	private String nome;
	private int quantidadeUtilizacoes;

	public Arma(String nome) {
		this.nome = nome;
	}

	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome){
		this.nome = nome;
	}

	public int getQuantidadeUtilizacoes() {
		return quantidadeUtilizacoes;
	}	
	
	public void aumentaQuantidade(){
		quantidadeUtilizacoes++;
	}
	
	

	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof Arma)) {
			return false;
		}
		Arma arma = (Arma) obj;

		if (arma.getNome() != null && this.nome != null) {
			return arma.getNome().equals(this.nome);
		}
		return false;
	}

	@Override
	public int hashCode() {
		return this.nome != null ? this.nome.hashCode() : 0;
	}

	@Override
	public String toString() {
		return this.nome + " " + this.quantidadeUtilizacoes;
	}

	@Override
	public int compareTo(Arma outro) {
		if (this.getQuantidadeUtilizacoes() > outro.getQuantidadeUtilizacoes()) {
			return -1;
		}
		if (this.getQuantidadeUtilizacoes() < outro.getQuantidadeUtilizacoes()) {
			return 1;
		}
		return 0;
	}
}
