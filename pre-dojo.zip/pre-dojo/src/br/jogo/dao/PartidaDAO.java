package br.jogo.dao;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import br.jogo.modelo.Arma;
import br.jogo.modelo.Jogador;
import br.jogo.modelo.TipoProcesso;
import br.jogo.util.Utilitaria;

public class PartidaDAO {
	
	private List<Jogador> jogadores = new ArrayList<>();
	private int maiorSequencia;
	private BufferedReader br;
	private String nomeMaiorSequencia;

	public List<Jogador> getJogadores() {
		if(jogadores == null){
			return new ArrayList<>();
		}
		return jogadores;
	}

	public int getMaiorSequencia() {
		return maiorSequencia;
	}		


	public void setNomeMaiorSequencia(String nome) {
		this.nomeMaiorSequencia = nome;
	}

	public String getNomeMaiorSequencia() {
		return nomeMaiorSequencia;
	}

	//processa e ordena a lista devolvendo o ranking
	public List<Jogador> obtemRanking(String txt) {		
		try {
			br = new BufferedReader(new FileReader(txt));
			String line;
			while ((line = br.readLine()) != null) {								
				processaLinhaDaPartida(line);
			}
		} catch (FileNotFoundException e) {
			System.out.println("Arquivo nao encontrado: " + e.toString());
			return new ArrayList<>();
		} catch (IOException e) {
			System.out.println("Erro ao ler arquivo: " + e.toString());
			return new ArrayList<>();
		}
		Collections.sort(jogadores);
		Collections.sort(jogadores.get(0).getArmas());
		checaAwardVencedor();
		return jogadores;
	}

	private void checaAwardVencedor() {			
		if(jogadores.get(0).getQuantidadeMortes() == 0){
			jogadores.get(0).ganhaAward();			
		}
	}

	private void processaLinhaDaPartida(String linha) {
		Utilitaria util = new Utilitaria();
		String[] campos = linha.split(" - ");
		Calendar dataHora = util.stringToCalendar(campos[0]);						
		if(!primeiraOuUltimaLinha(campos[1])){
			String[] objetos = campos[1].split(" ");			
			String arma = objetos[3].trim().contains("using") ? objetos[4] : "";
			if(!objetos[0].equals("<WORLD>")){
				processaListaDeJogadores(dataHora,objetos[0],arma,TipoProcesso.ASSASSINO);
			}
			processaListaDeJogadores(dataHora,objetos[2],arma,TipoProcesso.MORTO);
		}
	}

	private void processaListaDeJogadores(Calendar dataHora, String nome, String arma, TipoProcesso tipo) {
		Jogador jogador = new Jogador(nome);
		Arma armaDoJogador = new Arma(arma);
		if (!jogadores.isEmpty() && jogadores.contains(jogador)) {
			atualizaJogadorDaLista(dataHora,jogador,armaDoJogador,tipo);
		}else{
			AdicionaNovoJogador(dataHora,jogador,armaDoJogador,tipo);
		}
	}

	public boolean primeiraOuUltimaLinha(String linha) {
		if ((!linha.isEmpty()) && (linha.contains("started") || linha.contains("ended"))) {
			return true;
		}
		return false;
	}

	private void atualizaJogadorDaLista(Calendar dataHora, Jogador jogador, Arma armaDoJogador, TipoProcesso tipo) {
		Iterator<?> iterator = jogadores.iterator();
		while (iterator.hasNext()) {
			Jogador j = (Jogador) iterator.next();
			if (j.equals(jogador)) {
				if(tipo == TipoProcesso.ASSASSINO){
					j.aumentaAssassinatos(dataHora);
					j.addArma(armaDoJogador);
					atualizaMaiorSequencia(j);					
				}else{
					j.aumentaMortes();
				}
				break;
			}
		}
	}

	private void AdicionaNovoJogador(Calendar dataHora,Jogador jogador,Arma armaDoJogador,TipoProcesso tipo) {
		if(tipo == TipoProcesso.ASSASSINO){ 
			jogador.aumentaAssassinatos(dataHora);			
			jogador.addArma(armaDoJogador);
			atualizaMaiorSequencia(jogador);
		}else{
			jogador.aumentaMortes();
		}
		jogadores.add(jogador);		
	}

	private void atualizaMaiorSequencia(Jogador jogador) {		
		if(jogador.getSequencia() > this.maiorSequencia){
			this.maiorSequencia = jogador.getSequencia();
			setNomeMaiorSequencia(jogador.getNome());
		}		
	}
}
