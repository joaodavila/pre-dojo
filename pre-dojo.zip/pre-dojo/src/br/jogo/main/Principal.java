package br.jogo.main;

import java.io.IOException;
import java.util.List;

import br.jogo.dao.PartidaDAO;
import br.jogo.modelo.Jogador;

public class Principal {
	
	public static void main(String[] args) throws IOException {
		//String txt1 = "\\docs\\partida1.txt";	
		String txt2 = ".\\..\\docs\\partida2.txt";
		PartidaDAO partida = new PartidaDAO();
		List<Jogador> jogadores = partida.obtemRanking(txt2);
		String maiorSequencia = String.valueOf(partida.getMaiorSequencia());
		String jogadorComMaiorSequencia = String.valueOf(partida.getNomeMaiorSequencia());		
		GeradorCSV.geraArquivoCsv(jogadores, maiorSequencia, jogadorComMaiorSequencia, ".\\..\\docs\\ranking.csv");
	}
}
