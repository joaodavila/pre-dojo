package br.jogo.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Utilitaria {

	public Calendar stringToCalendar(String data) {
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat formataData = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
		try {
			cal.setTime(formataData.parse(data));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return cal;
	}

	public long calculaIntervaloEmSegundos(Calendar dataHoraAntes, Calendar dataHoraAtual) {
		
		return (dataHoraAtual.getTimeInMillis() - dataHoraAntes.getTimeInMillis())/1000;
	}
}
