package com.jogo;
import static org.junit.Assert.assertEquals;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Test;

import com.jogo.util.Utilitaria;


public class UtilitariaTest {

	private String dataStr = "23/04/2013 15:34:22";
	private SimpleDateFormat formataData = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");

	@Test
	public void data_entrada_e_saida_devem_ser_iguais() throws Exception {		
		//preparar		
		Utilitaria util = new Utilitaria();		
		//executar		
		Date dataFornecida = formataData.parse(dataStr);
		Date dataRecuperada = util.stringToCalendar(dataStr).getTime();		
		//validar
		assertEquals(dataFornecida,dataRecuperada );		
	}
	
	
}