package com.jogo;

import static org.junit.Assert.*;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.jogo.dao.PartidaDAO;
import com.jogo.modelo.Jogador;

public class PartidaDAOTest {
		
	private String txt1;
	private String txt2;
	private PartidaDAO partida1;
	private PartidaDAO partida2;
	private String linhaInicial;
	private String linhaFinal;
	private String linhaMeio;
	private List<Jogador> rankingParida1;
	private List<Jogador> rankingParida2;
 
	@Before
	public void setUp() throws Exception {
		//System.out.println(new File("\\docs").getCanonicalPath());
		txt1 = "docs\\partida1.txt";
		txt2 = "docs\\partida2.txt";
		partida1 = new PartidaDAO();
		partida2 = new PartidaDAO();		
		linhaInicial = "New match 11348965 has started";
		linhaMeio = "Roman killed Nick using M16";
		linhaFinal = "Match 11348965 has ended";
		rankingParida1 = partida1.obtemRanking(txt1);
		rankingParida2 = partida2.obtemRanking(txt2);
	}
	
	@Test
	public void ranking_partida1_deve_conter_dois_jogadores() throws Exception {
		
		assertEquals(2, rankingParida1.size());
	}
	
	@Test
	public void ranking_partida2_deve_conter_seis_jogadores() throws Exception {
		
		assertEquals(6, rankingParida2.size());
	}

	@Test
	public void roman_deve_vencer_partida1() {
		String nome = rankingParida1.get(0).getNome();		
		assertEquals("Roman",nome);
	}
	
	@Test
	public void romam_deve_ter_zero_mortes_partida1() throws Exception {
		int quantidadeMortes = rankingParida1.get(0).getQuantidadeMortes();		
		assertEquals(0,quantidadeMortes);
	}
	
	@Test
	public void roman_deve_vencer_partida2() {
		String nome = rankingParida2.get(0).getNome();		
		assertEquals("Roman",nome);
	}
	
	@Test
	public void linha_inicial_deve_retornar_true() throws Exception {
		boolean teste = partida1.primeiraOuUltimaLinha(linhaInicial);
		assertEquals(true,teste);
	}
	
	@Test
	public void linha_final_deve_retornar_true() throws Exception {
		boolean teste = partida1.primeiraOuUltimaLinha(linhaFinal);
		assertEquals(true,teste);
	}
	
	@Test
	public void linha_meio_deve_retornar_false() throws Exception {
		boolean teste = partida1.primeiraOuUltimaLinha(linhaMeio);
		assertEquals(false,teste);
	}
	
	@Test
	public void roman_deve_ganhar_um_award_partida1() throws Exception {
		int awardsTeste = 0;
		for(Jogador j : rankingParida1 ){
			if(j.getNome().equals("Roman")){
				awardsTeste = j.getAwards();
			}
		}		
		assertEquals(1,awardsTeste);
	}
	
	@Test
	public void roman_deve_ganhar_um_award_partida2() throws Exception {
		int awardsTeste = 0;
		for (Jogador j : rankingParida2) {
			if (j.getNome().equals("Roman")) {
				awardsTeste = j.getAwards();
			}
		}
		assertEquals(1, awardsTeste);
	}
	@Test
	public void arma_preferida_roman_partida2_deve_ser_MG3() throws Exception {
		
		String armaTeste = rankingParida2.get(0).getArmas().get(0).getNome();
		
		assertEquals("MG3", armaTeste);
	}
}
